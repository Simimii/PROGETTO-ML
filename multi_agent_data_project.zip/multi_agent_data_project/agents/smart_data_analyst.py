# agents/orchestrator_agent.py
import os
from pathlib import Path
import json
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_react_agent
from langchain_core.prompts import PromptTemplate
from langchain.memory import ConversationBufferWindowMemory

# Importa i tool specifici dell'orchestratore
from .tools import data_insights_tool
from .tools import data_operation_code_generator_tool
from .tools import execute_python_code_tool
from .tools import visualization_code_generator_tool
from .tools import format_dataframe_tool 
from .tools import generate_insight_explanation_tool 

from .data_processing_agent import run_data_processing_agent 
from .visualization_agent import run_visualization_agent 

# --- Configurazione Iniziale ---
project_root =Path(r'C:\Users\Utente\OneDrive\Desktop\DataScience\ML\multi_agent_data_project')
dotenv_path = project_root / ".env"
load_dotenv(dotenv_path=dotenv_path)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# LLM per l'Orchestratore 
orchestrator_llm = ChatOpenAI(api_key=OPENAI_API_KEY, model="gpt-4o-mini", temperature=0.3) # gpt-4o è una buona scelta

from langchain.tools import tool 

class DPAToolInput(BaseModel):
    task_description: str = Field(description="A clear, natural language description of the specific data processing task.")
   
### DPA tool wrapper
@tool
def data_processing_agent_tool_wrapper(json_input_string: str) -> dict:
    """
    Delegates a data processing task to the DataProcessingAgent.
    Input MUST be a JSON string with a "task_description" key.
    An optional "schema_info" key can also be included in the JSON string;
    if "schema_info" is missing or null, a default placeholder will be used.
    The DataProcessingAgent will then perform operations like loading data,
    filtering, aggregating, and calculations, returning a dictionary
    with the status and results (e.g., a path to a pickled DataFrame or a direct value).
    """
    print(f"[SDA -> DPA_WRAPPER] Received raw JSON string: {json_input_string}")
    try:
        input_dict = json.loads(json_input_string)
        task_description = input_dict.get("task_description")
        
      
        schema_info_value = input_dict.get("schema_info") 
        if schema_info_value is None: 
            schema_info_for_dpa = "SCHEMA_INFO_NOT_PROVIDED_BY_SDA"
        else:
            schema_info_for_dpa = schema_info_value 

        if not task_description:
            return {"status": "error", "error_message": "JSON input to DPA wrapper must contain 'task_description'."}

    except json.JSONDecodeError as e:
        return {"status": "error", "error_message": f"Invalid JSON input to DPA wrapper: {e}. Input was: {json_input_string}"}
    except Exception as e:
        return {"status": "error", "error_message": f"Error parsing JSON for DPA wrapper: {type(e).__name__} - {e}. Input was: {json_input_string}"}

    schema_print_snippet = ""
    if isinstance(schema_info_for_dpa, str):
        schema_print_snippet = schema_info_for_dpa[:100]
    elif isinstance(schema_info_for_dpa, dict):
        schema_print_snippet = str(schema_info_for_dpa)[:100] 
    
    print(f"[SDA -> data_processing_agent_tool_wrapper] Parsed Task: {task_description}, Parsed Schema for DPA: {schema_print_snippet}...")
    return run_data_processing_agent(task_description=task_description, schema_info=schema_info_for_dpa)

class VAToolInput(BaseModel): 
    task_description: str = Field(description="Description of the visualization needed (e.g., 'bar chart of sales by product').")
    input_data_pickle_path: str = Field(description="The absolute path to the pickled Pandas DataFrame that needs to be visualized.")
    data_description_for_prompt: str = Field(description="A textual description of the DataFrame's structure for the LLM.")

@tool 
def visualization_agent_tool_wrapper(json_input_string: str) -> dict: 
    """
    Delegates a visualization task. Input MUST be a JSON string with keys:
    "task_description", "input_data_pickle_path", "data_description_for_prompt".
    """
    print(f"[SDA -> VA_WRAPPER] Received raw JSON string: {json_input_string}")
    try:
        input_dict = json.loads(json_input_string)
        task_description = input_dict.get("task_description")
        input_data_pickle_path = input_dict.get("input_data_pickle_path")
        data_description_for_prompt = input_dict.get("data_description_for_prompt")

        if not task_description:
            return {"status": "error", "error_message": "JSON input to VA wrapper must contain 'task_description'."}
        if not input_data_pickle_path:
            return {"status": "error", "error_message": "JSON input to VA wrapper must contain 'input_data_pickle_path'."}
        if not data_description_for_prompt:
            
            return {"status": "error", "error_message": "JSON input to VA wrapper must contain 'data_description_for_prompt'."}

    except json.JSONDecodeError as e:
        return {"status": "error", "error_message": f"Invalid JSON input to VA wrapper: {e}. Input was: {json_input_string}"}
    except Exception as e:
        return {"status": "error", "error_message": f"Error parsing JSON for VA wrapper: {type(e).__name__} - {e}. Input was: {json_input_string}"}

    print(f"[SDA -> visualization_agent_tool_wrapper] Parsed Task: {task_description}, Parsed DataPath: {input_data_pickle_path}, Parsed DataDesc: {data_description_for_prompt[:100]}...")
    return run_visualization_agent(
        task_description=task_description,
        input_data_pickle_path=input_data_pickle_path,
        data_description_for_prompt=data_description_for_prompt
    )

### List of tools available to the SmartDataAnalyst (SDA) Orchestrator.
### Includes direct tools and wrappers for specialized agents.
sda_tools = [
    data_insights_tool,               # Tool diretto
    data_processing_agent_tool_wrapper, # Wrapper per il runner del DPA
    visualization_agent_tool_wrapper, # Wrapper per il runner del VA     
    format_dataframe_tool,
    generate_insight_explanation_tool
]


### Prompt Template for the SmartDataAnalyst (SDA) Orchestrator.
### This prompt defines SDA's persona, capabilities, available tools, and workflow.
### Key sections:
### - AVAILABLE DATASETS OVERVIEW: Informs SDA about the data it manages.
### - YOUR AVAILABLE TOOLS: Lists tools and their high-level purpose. Specific instructions for `format_dataframe_tool` and `generate_insight_explanation_tool`.
### - WORKFLOW FOR DATA-RELATED QUERIES: Step-by-step guide for SDA's reasoning.
###   - Step 3 (DATA PROCESSING): How to use DPA and what to expect. Crucial instructions for DPA's "task_description" to ensure all necessary columns for subsequent visualizations are prepared by DPA. Also clarifies "schema_info" handling for DPA.
###   - Step 4 (PRESENTING DATA AND/OR PREPARING FOR VISUALIZATION): Logic for deciding when to use `format_dataframe_tool` based on user's goal (see data vs. see chart).
###   - Step 5 (VISUALIZATION): How to use VA.
###   - Step 6 (SYNTHESIZE FINAL ANSWER): How to construct the response, including Markdown tables, chart paths (with specific phrasing "A chart has been generated and saved at: ..."), and the optional EXPLAINING THE RESULT substep using `generate_insight_explanation_tool`.
###   - Step 7 (GENERATING PROACTIVE SUGGESTIONS): Instructs SDA to offer follow-up questions.
###   - Step 9 (HANDLING INTERACTIVE REFINEMENT REQUESTS): Guides SDA on how to handle user requests to modify previous results, emphasizing memory recall for pickle paths and column descriptions (especially for using correct, potentially DPA-renamed, column names from previous `result_df_columns`).
### - STRICT RESPONSE FORMAT: ReAct style Thought/Action/Action Input/Observation. Emphasizes clear final `Thought` before `Final Answer`.

SDA_PROMPT_TEMPLATE_STR = """
You are SmartDataAnalyst, an AI orchestrator. Your goal is to understand complex user queries about specific datasets,
plan a sequence of actions (potentially involving multiple data processing steps before a final result or visualization),
delegate tasks to specialized agents or tools, and synthesize their outputs into a comprehensive final answer.
You have memory of the past few turns of conversation.

AVAILABLE DATASETS OVERVIEW:
- 'EntryAmministrati.csv': Personnel distribution (department, residence_region, gender, age_min, age_max, count). Keywords: staff, personnel, employees by department/region. **Note: When user queries refer to "administrations" or "municipalities" in the context of personnel distribution, consider using the 'department' column from this dataset as the primary proxy unless otherwise specified by schema or context.**
- 'EntryAccreditoStipendi.csv': Payment data (administration, age, gender, payment_method, amount). Keywords: payment, salary, stipend.
- 'EntryPendolarismo.csv': Commuting data (entity/administration, distance_min_km, distance_max_km, administered_count). Keywords: commute, travel, distance, mobility.
- 'EntryAccessoAmministrati.csv': User access data (users' region of residence, administration, age group, gender, and access method, occurrence_count). Keywords: access, login, portal, authentication, **access methods, user region**.
YOUR AVAILABLE TOOLS:
{tools}

`general_knowledge_tool` should ONLY be used for questions not related to the datasets.
`format_dataframe_tool` should ONLY be used after `data_processing_agent_tool_wrapper` returns a `dataframe_pickle_path`, to load that pickle and present its data as a Markdown table if the user needs to see the raw/aggregated data.
`generate_insight_explanation_tool` can be used AFTER you have a data table (from `format_dataframe_tool`) or a chart path (from `visualization_agent_tool_wrapper`) to provide a brief textual summary of what the result means in the context of the user's query. Only use it if the result is suitable for explanation (e.g., not for very simple row counts).

WORKFLOW FOR DATA-RELATED QUERIES:
1.  ANALYZE the user query: Understand the core intent. Identify ALL data sources needed (from AVAILABLE DATASETS OVERVIEW). Determine if the query implies a single data processing outcome or multiple sequential data transformations that build upon each other.
2.  SCHEMA GATHERING (for original CSVs, if needed for YOUR understanding or if the DPA task is very simple and about one CSV):
    If your plan involves the DPA loading an original CSV for the first time for THIS CURRENT QUERY, or if YOU need schema clarity to formulate the DPA's task, you MAY use `data_insights_tool`.
    Correct Usage Example for `data_insights_tool`:
    Action: data_insights_tool
    Action Input: EntryAccessoAmministrati.csv

3.  DATA PROCESSING:
    Use `data_processing_agent_tool_wrapper`.
    - Your "task_description" to the DPA MUST be a SINGLE, COMPREHENSIVE set of instructions for the ENTIRE data processing needed to answer the user's query directly. This is especially true for complex calculations like percentage distributions across multiple groups (e.g., different age segments compared within regions), where the DPA needs all data and grouping criteria in one go to calculate base totals correctly.
    - AVOID breaking down a single complex analytical goal into multiple sequential DPA calls where each DPA call only does a part of the filtering or aggregation if a single DPA script can achieve the entire goal. For instance, if the user asks for "percentage distribution of X among G1 and G2, by Y", your task to DPA should be "Process data to get percentage distribution of X for groups G1 and G2, broken down by Y". The DPA is responsible for all intermediate steps like creating G1/G2 categories, filtering, all necessary groupings, and the final calculation.
    - Action Input: A JSON string. This JSON string MUST contain a "task_description" key.
      It MAY optionally contain a "schema_info" key if YOU (SDA) have specific schema information to pass (e.g., from your `data_insights_tool` call). If not, omit "schema_info" or set it to "SCHEMA_INFO_NOT_PROVIDED_BY_SDA".
    A successful DPA Observation will be a dictionary with "status", "output_type", "value", "result_df_columns", and "result_df_dtypes".

4.  PRESENTING DataFrame RESULTS (If DPA returned `dataframe_pickle_path` AND user needs to see tabular data):
    Use `format_dataframe_tool`. Action Input: The `dataframe_pickle_path` string from DPA's Observation.

5.  VISUALIZATION (if requested/appropriate, AND DPA provided `dataframe_pickle_path`, 'result_df_columns', 'result_df_dtypes'):
    Use `visualization_agent_tool_wrapper`. Action Input: A JSON string with "task_description", "input_data_pickle_path", and "data_description_for_prompt".

6.  SYNTHESIZE FINAL ANSWER:
    - Include Markdown table from `format_dataframe_tool` if used.
    - If a chart was generated: State path "A chart has been generated and saved at: [path]" and describe it.
    - **EXPLAINING THE RESULT (Optional but Recommended):**
        If insights would be valuable, use `generate_insight_explanation_tool`.
        Action Input: JSON `{{"user_query": "...", "data_description": "...", "data_content_or_chart_description": "...", "chart_path": "..."}}`
        Append its output (preceded by "**Key Insight:**") to your final answer.
    - If any step failed, report error as per "HANDLING ERRORS...".

7.  GENERATING PROACTIVE SUGGESTIONS (After synthesizing the main answer):
    - Briefly review interaction. Think of 1-2 logical follow-up questions.
    - Append as "**Next Steps You Might Consider:** 1. ... 2. ..." or omit if no good suggestions.

8.  HANDLING INTERACTIVE REFINEMENT REQUESTS:
    - If user requests to MODIFY a RECENT PREVIOUS result (table or chart):
        a. IDENTIFY and RECALL context (EXACT `dataframe_pickle_path` from DPA's `temp_agent_outputs`, `result_df_columns`, `result_df_dtypes`).
        b. FORMULATE NEW TASK:
            - CHART REFINEMENT: Call `visualization_agent_tool_wrapper` with SAME pickle path, SAME data description (constructed from recalled DPA columns/types, e.g., "DataFrame has columns: ['RecalledCol1', ...]. Dtypes are: ..."), and NEW VA task for the change.
            - DATA TABLE REFINEMENT: Call `data_processing_agent_tool_wrapper` with NEW DPA task: "1. Load DataFrame from 'PREVIOUS_PICKLE_PATH_FROM_TEMP_AGENT_OUTPUTS'. 2. Perform new operation (sort/filter) on loaded data."
        c. Do NOT re-run initial processing from CSVs unless essential.

STRICT RESPONSE FORMAT (ReAct Style - FOLLOW THIS EXACTLY, EVERY SINGLE TIME, WITHOUT FAIL):
Thought: [Your concise reasoning.
 - If planning `data_insights_tool`, state exact filename.
 - If planning `data_processing_agent_tool_wrapper` for a complex query, state you'll provide a single comprehensive task.
 - For refinement, state you are recalling previous context like `dataframe_pickle_path` (e.g., "C:/.../temp_agent_outputs/df.pkl") and exact column names for `data_description_for_prompt`.
 - Your VERY LAST THOUGHT before `Final Answer:` MUST be simple: "I have received all necessary information from previous tool calls (or an error occurred). I will now synthesize the final answer for the user." THIS THOUGHT SHOULD NOT PROPOSE NEW ACTIONS.]

Action: [THIS LINE MUST CONTAIN *ONLY* THE EXACT NAME OF ONE TOOL FROM [{tool_names}]. NO ARGUMENTS, PARENTHESES, OR QUOTES ON THIS LINE.
Correct Example: `data_insights_tool`
Incorrect Example: `data_insights_tool("file.csv")` <- WRONG!]

Action Input: [THIS LINE MUST CONTAIN *ONLY* THE INPUT FOR THE TOOL.
- For `data_insights_tool` or `format_dataframe_tool`: a direct string (e.g., `EntryAccessoAmministrati.csv` or `C:/path/to/data.pkl`).
- For JSON-expecting tools (DPA wrapper, VA wrapper, explanation tool): THE JSON OBJECT string itself `{{"key": "value"}}`.
- CRITICAL: NO additional outer quotes or backticks around the Action Input content.]

Observation: [System-filled tool result.]
... (Repeat Thought/Action/Action Input/Observation cycle as needed. For example, after DPA provides a pickle, you might think "DPA provided a pickle. I need to format it." Action: format_dataframe_tool. Action Input: [path]. Observation: [markdown_table]. Then you might think "Table is formatted. Now I want an explanation." Action: generate_insight_explanation_tool. Action Input: [json_for_explanation]. Observation: [explanation_text].)

Thought: The last action was [NOME_ULTIMO_TOOL_USATO_CON_SUCCESSO, es. format_dataframe_tool o generate_insight_explanation_tool o visualization_agent_tool_wrapper, o data_processing_agent_tool_wrapper se ha restituito un valore diretto]. I have received its output. I have gathered all necessary components (e.g., Markdown table, chart path and description, textual explanation) OR an unrecoverable error occurred in a previous step. No further actions are needed for the current user query. I will now construct the Final Answer.
Final Answer: [A SINGLE, COHESIVE STRING containing the full response: Markdown table (if any), chart info "A chart has been generated and saved at: [path]" plus description (if any), explanation (if any), suggestions (if any). Or an error message if an earlier step definitively failed and no recovery or alternative was possible.]

HANDLING ERRORS FROM SPECIALIZED AGENTS/TOOLS:
- If `data_processing_agent_tool_wrapper` returns an error like "Agent stopped due to iteration limit":
    1. `Thought:` The DPA failed due to complexity. I will try to break the original user query into smaller, sequential data processing steps. My first step will be [describe step 1, e.g., "load the primary dataset"].
    2. `Action:` `data_processing_agent_tool_wrapper`
    3. `Action Input:` `{{"task_description": "Plan for step 1 only...", "schema_info": "..."}}`
    4. `Observation:` (Result of step 1, e.g., a pickle path)
    5. `Thought:` Step 1 was successful. The result is at [pickle_path_from_step_1]. Now I will plan step 2: [describe step 2, e.g., "filter the data from the previous pickle to find top N items"]. My task description to DPA for step 2 will explicitly mention loading data from '[pickle_path_from_step_1]'.
    6. `Action:` `data_processing_agent_tool_wrapper`
    7. `Action Input:` `{{"task_description": "1. Load DataFrame from pickle at '[pickle_path_from_step_1]'. 2. Perform operations for step 2...", "schema_info": "SCHEMA_INFO_NOT_PROVIDED_BY_SDA_FOR_PICKLE"}}`
    8. (Continue this pattern for subsequent steps, always referencing previous pickle outputs in the task_description for the DPA).
- If `format_dataframe_tool` fails because a pickle path (previously returned by DPA) is not found:
    1. `Thought:` The pickle file expected by `format_dataframe_tool` was not found. This means the DPA's previous step either didn't save it correctly, or I (SDA) made a mistake passing the path, OR the DPA's `Final Answer` incorrectly stated an `output_type` of "DataFrame" instead of "dataframe_pickle_path" with a valid path. I should NOT ask the DPA to "retrieve results from last operation" as it's stateless. I should re-evaluate the DPA's last output.
    2. If the DPA's last output *did* provide a pickle path but it was invalid, report an error: "Could not format the data table because the source file from data processing was not found at the expected location: [path]."
    3. If the DPA's last output had an `output_type` like "DataFrame" and `value` "result_df", this was an error by the DPA. I should report: "The Data Processing Agent did not correctly provide a savable output path for its result. Cannot display the data." I should NOT try to guess a pickle path.
Current User Query: {input}
Conversation History (most recent messages first):
{chat_history}

Begin!
Thought: {agent_scratchpad}
"""

sda_prompt = PromptTemplate(
    template=SDA_PROMPT_TEMPLATE_STR,
    input_variables=["input", "chat_history", "agent_scratchpad"],
).partial(
    tools="\n".join([f"- {tool.name}: {tool.description}" for tool in sda_tools]),
    tool_names=", ".join([t.name for t in sda_tools])
)

# SDA Memory
sda_memory = ConversationBufferWindowMemory(
    k=5, # Ricorda le ultime 5 interazioni
    memory_key="chat_history",
    input_key="input", # La query corrente dell'utente
    return_messages=True
)

# Creazione dell'Agente SDA
sda_agent_runnable = create_react_agent(orchestrator_llm, sda_tools, sda_prompt)
sda_agent_executor = AgentExecutor(
    agent=sda_agent_runnable,
    tools=sda_tools,
    memory=sda_memory,
    verbose=True,
    handle_parsing_errors="Check your Action formatting. Ensure the Action is a valid tool name and Action Input is correctly formatted for that tool.", # Messaggio d'errore generico ma utile
    max_iterations=15,
    early_stopping_method="force" 
)

def run_orchestrator(user_query: str, session_id: str = "default_session"): 
    """Runs the SmartDataAnalyst orchestrator with the user's query."""
    print(f"[run_orchestrator] Query: {user_query}")
    
    try:
        response = sda_agent_executor.invoke({"input": user_query})
        return response.get("output", "The orchestrator did not produce a final answer.")
    except Exception as e:
        print(f"ERROR in orchestrator: {e}")
        return f"An unexpected error occurred in the orchestrator: {str(e)}"

if __name__ == '__main__':
    # Test di base per l'orchestratore
    print("Testing Orchestrator (SmartDataAnalyst)...")
    # Test query 1
    query1 = "Calculate the percentage distribution of access methods to the NoiPA portal among users aged 18-30 compared to those over 50, broken down by region of residence."
    print(f"\n--- Running Test Query 1 ---\n{query1}")
    # answer1 = run_orchestrator(query1)
    # print(f"\nFinal Answer from Orchestrator for Query 1:\n{answer1}")

    # Test query 2 (esempio)
    query2 = "Identify the most used payment method for each age group and generate a graph showing whether there are correlations between gender and payment method preference."
    # print(f"\n--- Running Test Query 2 ---\n{query2}")
    # answer2 = run_orchestrator(query2)
    # print(f"\nFinal Answer from Orchestrator for Query 2:\n{answer2}")
    
    # Esempio di query generica
    # query_gen = "What is LangChain?"
    # print(f"\n--- Running General Query ---\n{query_gen}")
    # answer_gen = run_orchestrator(query_gen)
    # print(f"\nFinal Answer from Orchestrator for General Query:\n{answer_gen}")
    pass # Lascia i test commentati per ora