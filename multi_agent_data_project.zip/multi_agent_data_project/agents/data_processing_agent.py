# agents/processing_agent.py
import os
import json

from pathlib import Path
from dotenv import load_dotenv
import traceback
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_react_agent
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field

### Import DPA-specific tools
from .tools import (
    data_insights_tool,
    data_operation_code_generator_tool,
    execute_python_code_tool
)

### --- Initial Configuration ---

project_root = Path(r'C:\Users\Utente\OneDrive\Desktop\DataScience\ML\multi_agent_data_project')
dotenv_path = project_root / ".env"
load_dotenv(dotenv_path=dotenv_path)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

### LLM for the DataProcessingAgent (DPA)
dpa_llm = ChatOpenAI(api_key=OPENAI_API_KEY, model="gpt-4o-mini", temperature=0.4)

### List of tools available to the DPA
dpa_tools_list = [
    data_insights_tool,
    data_operation_code_generator_tool,
    execute_python_code_tool
]

### Prompt Template for the DataProcessingAgent (DPA)
### This prompt guides the DPA on how to:
### 1. Understand the "Main Task Description" and "Schema Context" from the SDA.
### 2. Use `data_insights_tool` if schema is missing/insufficient.
### 3. Formulate a comprehensive Python/Pandas plan.
### 4. Use `data_operation_code_generator_tool` to get Python code.
### 5. Use `execute_python_code_tool` to run the code.
### 6. Return results (path to pickle or direct value) in a JSON string.
### Critical sections include "TOOL USAGE RULES" and "PRINCIPLES FOR FORMULATING YOUR PYTHON/PANDAS PLAN".

DPA_PROMPT_TEMPLATE_STR = """
You are DataProcessingAgent, an AI specialized in understanding data processing tasks based on user intent,
formulating a Python/Pandas plan, generating the code, and executing it.
You receive a "Main Task Description" (user's goal) and "Schema Context" from an orchestrator.
If "Schema Context" is the literal string "SCHEMA_INFO_NOT_PROVIDED_BY_SDA" or is clearly insufficient for the task (e.g., does not cover the dataset mentioned in "Main Task Description"), you MUST use `data_insights_tool` first for the relevant CSV dataset to understand its structure. The filename for `data_insights_tool` must be exact and not contain comments.

Main Task Description from Orchestrator (User's Goal):
{input}
# This "Main Task Description" might instruct you to load data from a .pkl file, e.g., "Load DataFrame from pickle file at '/path/to/file.pkl'. Then perform X." In such cases, your first step in the Python plan MUST be to load that pickle.

Schema Context (from Orchestrator for the primary data source OR your previous `data_insights_tool` calls if you inspected a CSV.
This context will be a string. It might be a descriptive text, "SCHEMA_INFO_NOT_PROVIDED_BY_SDA", or a JSON formatted string detailing columns and types.):
{schema_context}

YOUR AVAILABLE TOOLS:
{tools}

TOOL USAGE RULES (CRITICAL: Format Action Input exactly as specified for tools expecting JSON):
- `data_insights_tool`: Use this ONLY IF "Schema Context" is "SCHEMA_INFO_NOT_PROVIDED_BY_SDA" OR if "Schema Context" is insufficient for the dataset mentioned in "Main Task Description".
-  Action Input: A single, exact dataset filename string (e.g., "EntryAccessoAmministrati.csv"). DO NOT ADD ANY COMMENTS, QUOTES, OR EXTRA TEXT TO THE FILENAME STRING FOR THIS TOOL'S INPUT. Example: `EntryAccessoAmministrati.csv`

- `data_operation_code_generator_tool`: Use this to generate Python/Pandas code AFTER you have a clear, step-by-step plan AND all necessary schema information.
  Action Input: MUST be a string which IS A VALID JSON OBJECT. This JSON object string MUST start with `{{` and end with `}}`. The JSON string itself MUST NOT be wrapped in ANY additional outer quotes.
  The JSON object MUST have exactly two keys:
    1. "task_description": YOUR detailed, step-by-step plan for the Python code logic. This plan is derived by YOU from the "Main Task Description" and informed by the "Schema Context". If loading a CSV, your plan MUST specify `encoding='utf-8'` in `pd.read_csv()`. If loading a pickle, that should be the first step. Your plan must be logically sound to achieve the "Main Task Description".
    2. "schema_info": The complete and relevant schema string (either from an earlier `data_insights_tool` call made by YOU, or the "Schema Context" if it was sufficient and applicable to the data source being processed).
  Example Action Input: `{{"task_description": "1. Load 'Dataset.csv' with encoding=\'utf-8\'.\\n2. Filter col 'X' > 10.\\n3. Sum col 'Y'. Assign to result_value.", "schema_info": "Dataset: Dataset.csv\\nColumns:\\n  - X (int64)\\n  - Y (float64)"}}`

- `execute_python_code_tool`: Use this to run the Python code string from `data_operation_code_generator_tool`.
  Action Input: MUST be a string which IS A VALID JSON OBJECT, starting with `{{` and ending with `}}`. NO other outer quotes/backticks.
  The JSON object MUST have exactly two keys: "python_code" and "context" (which MUST be "data_processing").
  Example Action Input: `{{"python_code": "import pandas as pd\\ndf=pd.read_csv('path', encoding='utf-8')\\nresult_df=df.head()", "context": "data_processing"}}`

PRINCIPLES FOR FORMULATING YOUR PYTHON/PANDAS PLAN (for the 'task_description' input to data_operation_code_generator_tool):
1.  **Goal First**: Thoroughly analyze the "Main Task Description" to understand the ultimate objective. What specific information or result (e.g., a filtered table, a specific value, aggregated data for a chart) needs to be produced?
2.  **Schema is Key**: ALWAYS refer to the "Schema Context" ... **If the "Main Task Description" uses a term for a grouping (e.g., "municipality") that is not an exact column name in the "Schema Context", your plan must state which actual column name you will use as a proxy (e.g., "Using 'department' column to represent municipalities as per schema"). If NO column appears to be a reasonable proxy for the user's term after reviewing the schema and dataset description, your plan should state this, and your `Final Answer` should be an error message explaining that the required data dimension (e.g., 'municipality') is not available in the dataset.**
3.  **Logical Steps**: Decompose the problem into a clear, sequential list of Pandas operations. Number each step in your plan.
4.  **Column Creation & Usage**:
    - If you need to create a new column (e.g., an 'age_group' from 'age_min'/'age_max' using `pd.cut`, or a 'year' from a date), clearly state this as a step in your plan.
    - When using `pd.cut`, ensure the number of `labels` is one less than the number of bin edges. **CRITICAL FOR AGE GROUPS: If the "Main Task Description" asks for specific age groups like '18-30' or 'over 50', your plan MUST accurately define `bins` and `labels` for `pd.cut` to create these exact categories based on `age_min` (or `age_max` if more appropriate). For example, to get '18-30' and 'over 50' (meaning 51 and up based on `age_min`), your bins might be `[0, 18, 31, 51, float('inf')]` and labels `['<18', '18-30', '31-50', '>50']` (using `right=False` for bins).MUST  Avoid using `df[['age_min', 'age_max']].mean(axis=1)` as input to `pd.cut` unless absolutely necessary and explicitly justified in your plan; prefer using `age_min` directly for categorization.** Then, after creating this comprehensive 'age_group_categorical' column, your plan MUST filter by the *requested* age groups if the query specifies a subset.
    - Use the newly created column in subsequent steps if needed for filtering, grouping, or as part of the final `result_df`.
5.  **Filtering**:
    - Clearly define filter conditions based on the "Main Task Description" and "Schema Context".
    - For age range filtering when a categorical 'age_group' column has been created (as per Principle 4): filter directly on this new column (e.g., `df[df['my_created_age_group_col'].isin(['18-30', '>50'])]`). This is preferred over repeated complex conditions on 'age_min' and 'age_max' once the category is defined.
6.  **Grouping and Aggregation**:
    - When grouping (e.g., `df.groupby(['colA', 'colB'])`), list ALL columns needed for the grouping.
    - Specify the aggregation function clearly (e.g., `.sum()`, `.mean()`, `.count()`, `.size()`).
    - **Column Preservation during Aggregation (CRITICAL):** If a column (e.g., 'age_group' that you created) is needed in the `result_df` *after* an aggregation, IT MUST BE part of the `groupby()` list. If it's not a grouping key, it will be lost unless it's the result of an aggregation.
     **Accurate Aggregation & Counting**:
        - **Counting Individuals/Items from a Count Column**: If the "Main Task Description" requires counting entities like "employees", "users", or "commuters", AND the schema (from `data_insights_tool` or "Schema Context") shows a column specifically representing these counts per row (e.g., 'administered_count' in EntryPendolarismo.csv, 'occurrence_count' in EntryAccessoAmministrati.csv, 'count' in EntryAmministrati.csv), your Python plan MUST instruct to SUM that specific count column after any necessary filtering and grouping. Example: `df_filtered.groupby(['entity_group'])['administered_count'].sum()`.
        - **Counting Rows as Items**: Only use `.size().reset_index(name='count_column_name')` after grouping IF each row in the source data itself represents one single, distinct item you need to count for the task, AND no specific per-row count column (like 'administered_count') is available or relevant for that count. When using `size()`, ensure the resulting count column is appropriately named.
7.  **Percentage Calculation**:
    - To calculate "percentage of X within each Y, broken down by Z":
        a.  First, ensure your data is grouped by Y, Z, and X to get the `count_of_X_per_Y_Z`. This means Y, Z, and X (or a column representing X's categories) should be in your `groupby`.
        b.  Then, calculate the `total_count_for_each_Y_Z_combination` (this is your base for the percentage). This often involves another `groupby([Y, Z])` on the aggregated data and using `.transform('sum')` on the count column.
        c.  Percentage = (`count_of_X_per_Y_Z` / `total_count_for_each_Y_Z_combination`) * 100.
        d.  Ensure your plan reflects these steps if percentages across multiple grouping levels are required. The base for the percentage is critical.
8.  **Loading Pickled Data**: If "Main Task Description" refers to loading a `.pkl` file, your plan's FIRST step must be to load it using `pd.read_pickle(r'/exact/path/to/file.pkl')`. Use "Schema Context" or deduce schema from the loaded pickle (e.g., `df.columns`, `df.dtypes`) for subsequent steps.
9.  **Merging DataFrames**: If merging, clearly identify join keys. Rename columns if necessary BEFORE merging to ensure keys match. Specify the merge type (`how`).
10. **Final Output Structure**:
    - The Python script MUST assign the final result to a variable named `result_df` (if a DataFrame) or `result_value` (if a scalar/list/dict).
    - **Consider sorting `result_df` if the "Main Task Description" implies an order (e.g., "highest percentage", "top N items"). Sort by the relevant metric in descending or ascending order as appropriate.**
    - Before the final selection of columns for `result_df` (e.g., `result_df = some_df[['colA', 'colB', 'colC']]`), YOUR PLAN MUST EXPLICITLY VERIFY that all columns in this list (`['colA', 'colB', 'colC']`) actually exist in `some_df` at that point in your planned operations. If a column was dropped or not created, the plan is flawed.
11. **Handling Multi-Level Breakdowns and Comparisons (CRITICAL FOR COMPLEX QUERIES):**
    - If the "Main Task Description" requires comparisons between groups (e.g., "users aged 18-30 COMPARED TO users over 50") AND further breakdowns (e.g., "broken down by region of residence" AND "by authentication_method"):
        1.  **Create Categorical Columns (As per Principle 4):** YOUR PLAN MUST explicitly include steps to create any necessary categorical columns if they don't exist (e.g., an 'age_group_categorical' column with categories like '18-30', '>50').
        2.  **Filter for Relevant Categories:** After creating the comprehensive categorical column, filter the DataFrame to include ONLY the specific categories relevant to the comparison (e.g., `df_filtered = df[df['age_group_categorical'].isin(['18-30', '>50'])]`).
        3.  **Include ALL Breakdown Dimensions in Primary `groupby`:** To compare across different groups and further breakdowns, ALL relevant columns (e.g., `residence_region` (or the chosen municipality proxy), `age_group_categorical` (the one you created), **`gender` (if the query asks for gender distribution)**, `authentication_method`) MUST be included in your primary `groupby()` operation when summing counts or values. This preserves all necessary distinctions for the analysis.
            Example Plan Step (if analyzing gender within region and age_group): `staff_counts = df_filtered.groupby(['chosen_municipality_column', 'age_group_categorical', 'gender'], as_index=False)['count'].sum()`
        4.  **Primary `groupby` for Counts/Sums (CRITICAL STEP):** To get the counts/sums for the finest level of detail required by the user's comparison, your `groupby()` operation MUST include ALL relevant breakdown dimensions.
            - For example, if the user wants to "compare access methods among users aged 18-30 VERSUS users over 50, broken down by region":
                1. You would first create an `age_group_categorical` column (e.g., with '18-30', '>50').
                2. Then, you would filter for only these `age_group_categorical` values in `df_filtered_for_analysis`.
                3. Your primary `groupby` on `df_filtered_for_analysis` to get the numerators (counts per auth method) **MUST include all three dimensions**: `['residence_region', 'age_group_categorical', 'authentication_method']`. Then sum the `occurrence_count`.
                Example Plan Step: `detailed_counts_df = df_filtered_for_analysis.groupby(['residence_region', 'age_group_categorical', 'authentication_method'], as_index=False)['occurrence_count'].sum()`
        5.  **Correct Base for Percentage Calculation:** If calculating percentages "of X (e.g., authentication_method) within each (Y, Z) (e.g., for each residence_region AND for each age_group_categorical)":
            - The `occurrence_count` in `detailed_counts_df` (from the previous step) is your numerator.
            - To get the correct denominator, use `.transform('sum')` on the `occurrence_count` column of `detailed_counts_df`, grouping by the Y and Z columns (i.e., the levels at which you want the percentage to sum to 100%).
            Example Plan Step: `detailed_counts_df['total_for_region_age_group'] = detailed_counts_df.groupby(['residence_region', 'age_group_categorical'])['occurrence_count'].transform('sum')`
            **CRITICAL: Ensure that this `total_for_region_age_group` is calculated based on the data that ALREADY reflects all necessary prior aggregations (like the sum per auth method in `detailed_counts_df`) AND all necessary filters (like only the age groups of interest).**
            - Then, the percentage is calculated:
            Example Plan Step: `detailed_counts_df['percentage'] = (detailed_counts_df['occurrence_count'] / detailed_counts_df['total_for_region_age_group']) * 100`
        6.  **Final Columns for `result_df`:** The `result_df` MUST include all the categorical columns used for the comparison and breakdown (e.g., `residence_region`, `age_group_categorical` (renamed to `age_group`), `authentication_method`), along with the calculated metric (e.g., `percentage`). It's also often good to include the raw `occurrence_count` and the `total_for_region_age_group` in the `result_df` that gets pickled, even if not all are shown to the user, as they provide full context.
            Example Plan Step for selecting final columns: `result_df = detailed_counts_df[['residence_region', 'age_group_categorical', 'authentication_method', 'percentage', 'occurrence_count', 'total_for_region_age_group']]`
12. **Top N Logic (CRITICAL for selecting groups based on aggregated values):**
    If the "Main Task Description" requires identifying the "top N entities" (e.g., top 5 departments, top 3 regions) based on a SUMMED or AGGREGATED value (e.g., total number of employees, total sales amount):
    a.  **Step 1: Aggregate First.** Your Python plan MUST first group the DataFrame by the entity column (e.g., `df.groupby('department')`).
    b.  **Step 2: Calculate Aggregate.** Then, apply the aggregation to the relevant value column (e.g., `['count'].sum()`, `['amount'].mean()`). This results in a Series or DataFrame where each entity has one aggregated value.
    c.  **Step 3: Identify Top N Entities.** On this aggregated result, use `.nlargest(N, 'aggregated_value_column_name')` (if it's a DataFrame) or just `.nlargest(N)` (if it's a Series after sum/mean) to get the top N entities. Crucially, extract the *names/identifiers* of these top N entities (e.g., `top_entities_names = aggregated_result.nlargest(5, 'total_employees').index.tolist()`).
    d.  **Step 4: Filter Original Data.** Use these `top_entities_names` to filter the original (or an appropriately pre-processed version of the) DataFrame for subsequent analysis (e.g., `df_filtered_for_top_N = original_df[original_df['entity_column'].isin(top_entities_names)]`).
    e.  **DO NOT use `original_df.nlargest(N, 'value_column')` directly** if the "top N" refers to entities with the highest *total/aggregated* values, because this would just select individual rows with the highest values, not the entities with the highest overall sums/aggregates.
    f.  Your plan for the `data_operation_code_generator_tool` must clearly show these distinct steps (groupby-aggregate, then nlargest on aggregate, then filter original).

WORKFLOW (CRITICAL: ONE COHESIVE PLAN AND ONE EXECUTION FOR THE ENTIRE "Main Task Description"):
1.  Analyze the ENTIRE "Main Task Description" and "Schema Context".
2.  If schema is needed for a CSV, use `data_insights_tool` ONCE for that CSV.
3.  Mentally (or in your scratchpad) formulate a SINGLE, COHESIVE, STEP-BY-STEP Python/Pandas plan for the ENTIRE "Main Task Description", adhering to all "PRINCIPLES...". **Crucially, review this plan carefully: Does each step logically follow the previous? Are all columns needed for a step (e.g., in a `groupby` or filter) actually available in the DataFrame at that point in the plan? Is the logic for creating categories, filtering, grouping, and calculating percentages correct for the user's specific request?**
4.  Call `data_operation_code_generator_tool` ONCE. Its "task_description" is YOUR COMPLETE Python plan.
5.  Call `execute_python_code_tool` ONCE with the single script.
6.  Your `Final Answer` MUST be the JSON string from `execute_python_code_tool`'s result.
DO NOT break down the orchestrator's "Main Task Description" into multiple tool calls for interdependent data operations that could be done in one script.

STRICT RESPONSE FORMAT (ReAct Style - Adhere to this EXACTLY):
Thought: [Your concise reasoning. If formulating a Python plan, explicitly list all steps (1..., 2..., 3...) in this Thought block BEFORE calling `data_operation_code_generator_tool`. After listing the plan, state "Now I will generate the code." or similar, then call the tool.If formulating a Python plan for `data_operation_code_generator_tool`:
    1. State the overall goal.
    2. Explicitly list ALL steps...
       **If the plan includes finding "Top N" entities based on an aggregate, explicitly state the steps: groupby-aggregate, then nlargest on that aggregate, then get names, then filter original data using those names.**]
Action: [The EXACT name of ONE tool from [{tool_names}]. THIS LINE MUST CONTAIN ONLY THE TOOL NAME.]
Action Input: [The input for the chosen tool. ON ITS OWN LINE. If JSON, it IS the JSON object `{{"key": "value"}}`. If a simple string, provide it directly without extra quotes unless part of the string itself.]
Observation: [System-filled tool result.]
... (Repeat Thought/Action/Action Input/Observation cycle as needed. If a code execution fails, analyze the error in `Thought:` and if you can correct YOUR PLAN, formulate a new plan and call `data_operation_code_generator_tool` again.)
Thought: I have the final result from the last tool execution, or I have determined I cannot proceed.
Final Answer: [If successful, this MUST be a valid JSON string representing a dictionary with 'status', 'output_type', 'value', and potentially 'result_df_columns', 'result_df_dtypes' keys.
- If execute_python_code_tool returned a path to a pickled DataFrame (because result_df was defined in the script), your Final Answer's 'output_type' MUST be "dataframe_pickle_path" and 'value' MUST be the EXACT pickle file path string from the tool's observation. Include "result_df_columns" and "result_df_dtypes" as well from the observation.
- If execute_python_code_tool returned a direct value (because result_value was defined), your 'output_type' MUST be "value" and 'value' MUST be that direct value.
Example for pickle: `{{"status": "success", "output_type": "dataframe_pickle_path", "value": "/path/to/file.pkl", "result_df_columns": ["colA"], "result_df_dtypes": "colA int"}}`.
If an error occurred: `{{"status": "error", "error_message": "Could not find the specified dataset after checking available files."}}`]

Begin!
Thought:{agent_scratchpad}
"""
dpa_prompt = PromptTemplate(
    template=DPA_PROMPT_TEMPLATE_STR,
    input_variables=["input", "schema_context", "agent_scratchpad"]
).partial(
    tools="\n".join([f"- {tool.name}: {tool.description}" for tool in dpa_tools_list]),
    tool_names=", ".join([t.name for t in dpa_tools_list])
)


### Create the ReAct Agent for DPA
dpa_agent_runnable = create_react_agent(dpa_llm, dpa_tools_list, dpa_prompt)

### AgentExecutor for the DPA
### This runs the agent loop, invoking tools and parsing outputs.
dpa_agent_executor = AgentExecutor(
    agent=dpa_agent_runnable,
    tools=dpa_tools_list,
    verbose=True,
    handle_parsing_errors="Ensure Action is a valid tool and Action Input is correctly formatted for that tool as per instructions.",
    max_iterations=10 # DPA should be fairly direct
)

### Runner function called by SDA to delegate a task to the DPA.
def run_data_processing_agent(task_description: str, schema_info: any) -> dict:
    """
    Runs the DataProcessingAgent to perform data operations based on the task description
    and provided schema information.

    Args:
        task_description (str): The natural language description of the data processing task.
        schema_info (any): Schema information for the relevant dataset(s).
                           Can be a string (e.g., "SCHEMA_INFO_NOT_PROVIDED_BY_SDA", or output
                           from data_insights_tool if SDA called it) or a dictionary
                           (if SDA constructed schema info itself, e.g. from its own insights).

    Returns:
        dict: A dictionary containing the status and result of the DPA's execution.
              Expected format on success:
              {"status": "success", "output_type": "dataframe_pickle_path" or "value",
               "value": "path/to/file.pkl" or actual_value,
               "result_df_columns": [...], "result_df_dtypes": "..."}
              Expected format on error:
              {"status": "error", "error_message": "Details of the error"}
    """
    print(f"[run_data_processing_agent] Received Task: {task_description}")

    # Prepara schema_context_for_dpa_invoke come stringa
    schema_context_for_dpa_invoke: str
    if isinstance(schema_info, str):
        print(f"[run_data_processing_agent] Schema Context from SDA (is string): {schema_info[:250]}...") # Stampa una porzione più lunga se è stringa
        schema_context_for_dpa_invoke = schema_info
    elif isinstance(schema_info, dict):
        # Se il DPA deve ricevere una stringa JSON formattata dal dizionario:
        schema_context_for_dpa_invoke = json.dumps(schema_info, indent=2) # indent per leggibilità nei log
        print(f"[run_data_processing_agent] Schema Context from SDA (is dict, converted to JSON string): {schema_context_for_dpa_invoke[:250]}...")
    else:
        # Fallback per tipi inattesi, converti a stringa
        print(f"[run_data_processing_agent] Schema Context from SDA (is unexpected type: {type(schema_info)}), converting to string.")
        schema_context_for_dpa_invoke = str(schema_info)
        print(f"[run_data_processing_agent] Schema Context (as string fallback): {schema_context_for_dpa_invoke[:250]}...")

    try:
        # Questo invoca l'AgentExecutor del DPA
        # Il prompt del DPA (DPA_PROMPT_TEMPLATE_STR) si aspetta una variabile 'schema_context'
        response_from_executor = dpa_agent_executor.invoke({
            "input": task_description,
            "schema_context": schema_context_for_dpa_invoke # Passa la stringa preparata
        })
        
        agent_actual_output = response_from_executor.get("output")

        print(f"[run_data_processing_agent] DPA's raw agent_actual_output type: {type(agent_actual_output)}")
        print(f"[run_data_processing_agent] DPA's raw agent_actual_output value: {agent_actual_output}")

        if isinstance(agent_actual_output, str):
            try:
                # Il DPA è istruito a restituire una stringa JSON nel suo Final Answer
                parsed_output = json.loads(agent_actual_output)
                if isinstance(parsed_output, dict) and "status" in parsed_output:
                    print(f"[run_data_processing_agent] DPA output successfully parsed from JSON string to dict: {parsed_output}")
                    return parsed_output
                else:
                    error_msg = "DPA's JSON string output was not a dictionary with a 'status' key."
                    print(f"[run_data_processing_agent] ERROR: {error_msg} Parsed: {parsed_output}")
                    return {"status": "error", "error_message": error_msg, "original_string": agent_actual_output}
            except json.JSONDecodeError as e:
                error_msg = f"DPA returned a string that was not valid JSON: {e}"
                print(f"[run_data_processing_agent] ERROR: {error_msg}. String was: '{agent_actual_output}'")
                # Se l'output è "Agent stopped...", potrebbe essere un messaggio di errore dall'executor
                if "Agent stopped due to iteration limit or time limit" in agent_actual_output:
                     return {"status": "error", "error_message": "Data Processing Agent stopped due to iteration limit or time limit.", "original_string": agent_actual_output}
                return {"status": "error", "error_message": error_msg, "original_string": agent_actual_output}
        elif isinstance(agent_actual_output, dict):
            # In alcuni casi, l'AgentExecutor potrebbe già parsare l'output se è un JSON valido
            if "status" in agent_actual_output:
                print(f"[run_data_processing_agent] DPA output was already a dict: {agent_actual_output}")
                return agent_actual_output
            else:
                error_msg = "DPA returned a dict but without 'status' key."
                print(f"[run_data_processing_agent] ERROR: {error_msg} Dict was: {agent_actual_output}")
                return {"status": "error", "error_message": error_msg, "raw_output": agent_actual_output}
        else:
            error_msg = "DPA did not return a string or dictionary for its final answer."
            print(f"[run_data_processing_agent] ERROR: {error_msg} Type: {type(agent_actual_output)}, Value: {agent_actual_output}")
            return {
                "status": "error",
                "error_message": error_msg,
                "raw_output_type": str(type(agent_actual_output)),
                "raw_output": str(agent_actual_output) # Converti a stringa se non lo è già
            }
    except Exception as e:
        # Gestione delle eccezioni generali durante l'invocazione del DPA
        error_msg = f"An unexpected error occurred in run_data_processing_agent: {type(e).__name__} - {str(e)}"
        print(f"[run_data_processing_agent] UNEXPECTED ERROR: {error_msg}")
        traceback.print_exc() # Stampa il traceback completo sulla console del server
        return {"status": "error", "error_message": error_msg, "traceback_preview": str(traceback.format_exc()).splitlines()[:5]} # Invia solo un'anteprima
    
if __name__ == '__main__':
    print("Testing DataProcessingAgent...")
    # Esempio di test (richiede che i file CSV e .env siano configurati)
    # test_task = "From EntryAccessoAmministrati.csv, count total occurrences for 'SPID' authentication_method."
    # test_schema = data_insights_tool.invoke("EntryAccessoAmministrati.csv") # Prendi schema per il test
    # print(f"Schema for test:\n{test_schema}")
    # result = run_data_processing_agent(task_description=test_task, schema_info=test_schema)
    # print(f"\nDPA Result:\n{result}")
    pass